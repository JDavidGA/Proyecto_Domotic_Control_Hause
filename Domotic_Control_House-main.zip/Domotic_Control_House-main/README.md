 # Domotic_Control_House

![image](https://user-images.githubusercontent.com/71275875/170284760-4d65903c-f91c-408b-996d-d94ec361746f.png)

Nombre(s) del(os) docente(s) entrenador(es):

Hugo Alexander Peña	
hapena@educacionbogota.edu.co 

Wilson Hernan Perez Correa	
wperezcor@educacionbogota.edu.co

Integrantes:

Juan David Gomez Alarcon

Juan Manuel Cardona Castillo 

Yoiser Moisés Padrón Rojas

Julian Felipe Garzón Rico

Escenario Olímpico: Cambio climático

Git: https://github.com/hapena/Domotic_Control_House 

Video: https://youtu.be/qmGS3f5XoQ0 

Canal IoT:   https://thingspeak.com/channels/1807893

Wokwi Simulación:   https://wokwi.com/projects/336977704738882132 

Diseño del prototipo:

![Domotic Control House ver2_bb](https://user-images.githubusercontent.com/71275875/184920338-f26e3a95-b05a-4923-8b48-e6cc87ed1812.jpg)

Distribucion de Pines:

![image](https://user-images.githubusercontent.com/71275875/184920499-4ec221e6-9c72-456d-a8c7-b186a1887b58.png)

Diagrama de flujo del Codigo:

![Diagramas de flujo](https://user-images.githubusercontent.com/71275875/184920687-33d07498-0a8e-4101-8b07-97fc64280250.jpeg)




